// template = - [header :your header as HTML] [description": "description goes here as HTML] ,... //multiple
const whats_new_log = `   
- [Improvement] UI Bugfixes (Dark-mode Darker color for trace, Trace-inline tool editor detect mode you selected by default).
- [Improvement] XML declaration preserved by code beautify function.
- [Plugin] Performance stats plugin has better color for dark mode.
- [Plugin] Settings Pane Resizer plugin opens settings pane on page load even if Pause mode is active.
- [Feature] Color mode detected a theme and applied by default (in case of dark mode).
- [Feature] More compatibale with DARK CPI extension dark mode.
- [Feature] Position of popup is now state aware.
- [Feature] Body download option now with proper extension.
- [Feature] Text wrap option and theme of editor has clear information.
- [Feature] General UI Bugfix & backend global element to organize. [Read more here with snapshot note](https://github.com/dbeck121/CPI-Helper-Chrome-Extension/pull/194). Special thanks to [Omkar](https://github.com/incpi).
- [Fix] Solved problem with activating trace in situations with multiple runtimes.
`;
